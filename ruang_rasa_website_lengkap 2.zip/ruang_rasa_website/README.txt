WEBSITE RUANG RASA – VERSI LENGKAP

Cara menggunakan:
1. Ekstrak file ZIP ke komputer.
2. Pastikan folder assets tetap berada di samping index.html.
3. Buka index.html menggunakan browser.

Website berbahasa Indonesia dan sudah dilengkapi foto poster, foto logo resmi yang diambil dari lembar identitas brand, bagian profil brand, kategori kopi dan non-kopi, serta tautan Instagram.
